/*
 * Copyright (C) 2009 - 2019 Xilinx, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <stdio.h>

#include "xparameters.h"
#include "xgpio_l.h"

#include "netif/xadapter.h"

#include "platform.h"
#include "platform_config.h"
#if defined (__arm__) || defined(__aarch64__)
#include "xil_printf.h"
#endif

#include "lwip/tcp.h"
#include "xil_cache.h"

#if LWIP_IPV6==1
#include "lwip/ip.h"
#else
#if LWIP_DHCP==1
#include "lwip/dhcp.h"
#endif
#endif


/*
//Etapes de d�codage de la machine d'�tat
//La commande SET 1234; ou SET 123; ou SET 12; ou SET 1;
typedef enum EtapeDansLeDecodage
{INIT, CAR_S, CAR_E, CAR_T, CAR_SPACE,CAR_VAL1, CAR_VAL2,CAR_VAL3,CAR_VAL4, CAR_POINT}
tenuEtapeDansLeDecodage;

// gestion de l'etape en cours
tenuEtapeDansLeDecodage enuEtapeDansLeDecodage = INIT;

// retourn 1 si fin de d�codage
int calcul_de_etape_suivante(tenuEtapeDansLeDecodage *enuEtapeDansLeDecodage, char prochain_cara, int *iValeur)
{

	static char valeur[4+1]="";
	*iValeur=0;
	tenuEtapeDansLeDecodage etape = *enuEtapeDansLeDecodage;


	switch(etape)
	{
		case INIT:
			if (prochain_cara=='S')
				*enuEtapeDansLeDecodage = CAR_S;
			else
				*enuEtapeDansLeDecodage=INIT;
			return 0;
			break;

		case CAR_S:
			if (prochain_cara=='E')
				*enuEtapeDansLeDecodage = CAR_E;
			else
				*enuEtapeDansLeDecodage=INIT;
			return 0;
			break;
		case CAR_E:
			if (prochain_cara=='T')
				*enuEtapeDansLeDecodage = CAR_T;
			else
				*enuEtapeDansLeDecodage=INIT;
			return 0;
			break;
		case CAR_T:
			if (prochain_cara==' ')
				*enuEtapeDansLeDecodage = CAR_SPACE;
			else
				*enuEtapeDansLeDecodage=INIT;
			return 0;
			break;
		case CAR_SPACE:
			if (prochain_cara=='0' || prochain_cara=='1'|| prochain_cara=='2' || prochain_cara=='3' || \
				prochain_cara=='4' || prochain_cara=='5'|| prochain_cara=='6' || prochain_cara=='7'|| \
				prochain_cara=='8'|| prochain_cara=='9')
			{
						*enuEtapeDansLeDecodage = CAR_VAL1;
						valeur[0]=prochain_cara; //m�morise le caractere
						return 0;
			}
			else
			{
				*enuEtapeDansLeDecodage=INIT;
				return -1; //error
			}

			break;
		case CAR_VAL1:
			if (prochain_cara=='0' || prochain_cara=='1'|| prochain_cara=='2' || prochain_cara=='3' || \
				prochain_cara=='4' || prochain_cara=='5'|| prochain_cara=='6' || prochain_cara=='7'|| \
				prochain_cara=='8'|| prochain_cara=='9' )
			{
					*enuEtapeDansLeDecodage = CAR_VAL2;
					valeur[1]=prochain_cara;
					return 0;
					break;
			}
			else
			{
				if  (prochain_cara==';')
				{
					*enuEtapeDansLeDecodage=CAR_POINT;
					valeur[2]='\0';
					*iValeur=atoi(valeur);
					return 1;
					break;
				}
				else
				{
					*enuEtapeDansLeDecodage=INIT;
					return -1;
					break;
				}
			}
		case CAR_VAL2:
			if (prochain_cara=='0' || prochain_cara=='1'|| prochain_cara=='2' || prochain_cara=='3' || \
				prochain_cara=='4' || prochain_cara=='5'|| prochain_cara=='6' || prochain_cara=='7'|| \
				prochain_cara=='8'|| prochain_cara=='9' )
				{
					*enuEtapeDansLeDecodage = CAR_VAL3;
					valeur[2]=prochain_cara;
					return 0;
					break;
				}
				else
				{
					if  (prochain_cara==';')
					{
						*enuEtapeDansLeDecodage=CAR_POINT;
						valeur[2]='\0';
						*iValeur=atoi(valeur);
						return 1;
						break;
					}
					else
					{
						*enuEtapeDansLeDecodage=INIT;
						return -1;//erreur
						break;
					}
				}

		case CAR_VAL3:
				if (prochain_cara=='0' || prochain_cara=='1'|| prochain_cara=='2' || prochain_cara=='3' || \
					prochain_cara=='4' || prochain_cara=='5'|| prochain_cara=='6' || prochain_cara=='7'|| \
					prochain_cara=='8'|| prochain_cara=='9' )
					{
						*enuEtapeDansLeDecodage = CAR_VAL4;
						valeur[3]=prochain_cara;
						return 0;
						break;
					}
					else
					{
						if  (prochain_cara==';')
						{
							*enuEtapeDansLeDecodage=INIT;
							valeur[3]='\0';
							*iValeur=atoi(valeur);
							return 1;
							break;
						}
						else
						{
							*enuEtapeDansLeDecodage=INIT;
							return -1;
							break;
						}
					}
		case CAR_VAL4:
			if (prochain_cara=='0' || prochain_cara=='1'|| prochain_cara=='2' || prochain_cara=='3' || \
				prochain_cara=='4' || prochain_cara=='5'|| prochain_cara=='6' || prochain_cara=='7'|| \
				prochain_cara=='8'|| prochain_cara=='9' )
				{
					*enuEtapeDansLeDecodage = CAR_POINT;
					valeur[4]=prochain_cara;
					return 0;
					break;
				}
				else
				{
					if  (prochain_cara==';')
					{
						*enuEtapeDansLeDecodage=INIT;
						valeur[4]='\0';
						*iValeur=atoi(valeur);
						return 1;
						break;
					}
					else
					{
						*enuEtapeDansLeDecodage=INIT;
						return -1;
						break;
					}
				}

		case CAR_POINT:
			if  (prochain_cara==';')
			{
				*enuEtapeDansLeDecodage=INIT;
				valeur[5]='\0';
				*iValeur=atoi(valeur);
				return 1;
				break;
			}
			else
			{
				*enuEtapeDansLeDecodage=INIT;
				return -1;
				break;
			}


		}

  return 0;

}
*/



/*#define GPIO_REG_BASEADDR	0x40000000
#define GPIO_REG_TRI		0x04
#define GPIO_REG_DATA		0x00

#define LED_CHANNEL	1

void write_data_DAC(uint16_t u16Data)
{

  //Read-modify-write
  uint16_t u16Mot=0;

  //11 CLK(0) CS(0) DATA(11:0)
  //CS=0, CLK=0 et on positionne la data
  u16Mot = 0xC000 + (0<<13) + (0<<12) + u16Data;
  XGpio_WriteReg((GPIO_REG_BASEADDR),GPIO_REG_DATA, u16Mot); //1 pour input

  //11 CLK CS DATA(11:0)
  //CS=0, CLK=1 et on positionne la data
  u16Mot = 0xC000 + (0x2000) + (0<<12) + u16Data;
  XGpio_WriteReg((GPIO_REG_BASEADDR),GPIO_REG_DATA, u16Mot); //1 pour input

  //11 CLK CS DATA(11:0)
  //CS=0, CLK=0 et on positionne la data
  u16Mot = 0xC000 + (0<<13) + (0<<12) + u16Data;
  XGpio_WriteReg((GPIO_REG_BASEADDR),GPIO_REG_DATA, u16Mot); //1 pour input

	return;
}
*/


/* defined by each RAW mode application */
void print_app_header();
int start_application();
int transfer_data();
void tcp_fasttmr(void);
void tcp_slowtmr(void);

/* missing declaration in lwIP */
void lwip_init();

#if LWIP_IPV6==0
#if LWIP_DHCP==1
extern volatile int dhcp_timoutcntr;
err_t dhcp_start(struct netif *netif);
#endif
#endif

extern volatile int TcpFastTmrFlag;
extern volatile int TcpSlowTmrFlag;
static struct netif server_netif;
struct netif *echo_netif;

#if LWIP_IPV6==1
void print_ip6(char *msg, ip_addr_t *ip)
{
	print(msg);
	xil_printf(" %x:%x:%x:%x:%x:%x:%x:%x\n\r",
			IP6_ADDR_BLOCK1(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK2(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK3(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK4(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK5(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK6(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK7(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK8(&ip->u_addr.ip6));

}
#else
void
print_ip(char *msg, ip_addr_t *ip)
{
	print(msg);
	xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip),
			ip4_addr3(ip), ip4_addr4(ip));
}

void
print_ip_settings(ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw)
{

	print_ip("Board IP: ", ip);
	print_ip("Netmask : ", mask);
	print_ip("Gateway : ", gw);
}
#endif

#if defined (__arm__) && !defined (ARMR5)
#if XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT == 1 || XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT == 1
int ProgramSi5324(void);
int ProgramSfpPhy(void);
#endif
#endif

#ifdef XPS_BOARD_ZCU102
#ifdef XPAR_XIICPS_0_DEVICE_ID
int IicPhyReset(void);
#endif
#endif

int main()
{
#if LWIP_IPV6==0
	ip_addr_t ipaddr, netmask, gw;

#endif
	/* the mac address of the board. this should be unique per board */
	unsigned char mac_ethernet_address[] =
	{ 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };

	echo_netif = &server_netif;
#if defined (__arm__) && !defined (ARMR5)
#if XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT == 1 || XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT == 1
	ProgramSi5324();
	ProgramSfpPhy();
#endif
#endif

/* Define this board specific macro in order perform PHY reset on ZCU102 */
#ifdef XPS_BOARD_ZCU102
	if(IicPhyReset()) {
		xil_printf("Error performing PHY reset \n\r");
		return -1;
	}
#endif

	init_platform();

#if LWIP_IPV6==0
#if LWIP_DHCP==1
    ipaddr.addr = 0;
	gw.addr = 0;
	netmask.addr = 0;
#else
	/* initialize IP addresses to be used */
	IP4_ADDR(&ipaddr,  192, 168,   1, 10);
	IP4_ADDR(&netmask, 255, 255, 255,  0);
	IP4_ADDR(&gw,      192, 168,   1,  1);
#endif
#endif
	print_app_header();

	lwip_init();

#if (LWIP_IPV6 == 0)
	/* Add network interface to the netif_list, and set it as default */
	if (!xemac_add(echo_netif, &ipaddr, &netmask,
						&gw, mac_ethernet_address,
						PLATFORM_EMAC_BASEADDR)) {
		xil_printf("Error adding N/W interface\n\r");
		return -1;
	}
	for (volatile long wait=0; wait < 100000; wait++);
#else
	/* Add network interface to the netif_list, and set it as default */
	if (!xemac_add(echo_netif, NULL, NULL, NULL, mac_ethernet_address,
						PLATFORM_EMAC_BASEADDR)) {
		xil_printf("Error adding N/W interface\n\r");
		return -1;
	}
	echo_netif->ip6_autoconfig_enabled = 1;

	netif_create_ip6_linklocal_address(echo_netif, 1);
	netif_ip6_addr_set_state(echo_netif, 0, IP6_ADDR_VALID);

	print_ip6("\n\rBoard IPv6 address ", &echo_netif->ip6_addr[0].u_addr.ip6);

#endif
	netif_set_default(echo_netif);

	/* now enable interrupts */
	platform_enable_interrupts();

	/* specify that the network if is up */
	netif_set_up(echo_netif);

#if (LWIP_IPV6 == 0)
#if (LWIP_DHCP==1)
	/* Create a new DHCP client for this interface.
	 * Note: you must call dhcp_fine_tmr() and dhcp_coarse_tmr() at
	 * the predefined regular intervals after starting the client.
	 */
	dhcp_start(echo_netif);
	dhcp_timoutcntr = 24;

	while(((echo_netif->ip_addr.addr) == 0) && (dhcp_timoutcntr > 0))
		xemacif_input(echo_netif);

	if (dhcp_timoutcntr <= 0) {
		if ((echo_netif->ip_addr.addr) == 0) {
			xil_printf("DHCP Timeout\r\n");
			xil_printf("Configuring default IP of 192.168.1.10\r\n");
			IP4_ADDR(&(echo_netif->ip_addr),  192, 168,   1, 10);
			IP4_ADDR(&(echo_netif->netmask), 255, 255, 255,  0);
			IP4_ADDR(&(echo_netif->gw),      192, 168,   1,  1);
		}
	}

	ipaddr.addr = echo_netif->ip_addr.addr;
	gw.addr = echo_netif->gw.addr;
	netmask.addr = echo_netif->netmask.addr;
#endif

	print_ip_settings(&ipaddr, &netmask, &gw);

#endif
	/* start the application (web server, rxtest, txtest, etc..) */
	start_application();
	for (volatile long wait=0; wait < 100000; wait++);

	/*
	* Set the direction for all signals to be outputs
	 */
	//XGpio_WriteReg((GPIO_REG_BASEADDR),GPIO_REG_TRI, 0xC000); //1 pour input


	//uint16_t u16Data=0;

	/* receive and process packets */
	while (1) {
		if (TcpFastTmrFlag) {
			tcp_fasttmr();
			TcpFastTmrFlag = 0;
		}

		if (TcpSlowTmrFlag) {
			tcp_slowtmr();
			TcpSlowTmrFlag = 0;
		}

		xemacif_input(echo_netif);
		transfer_data();

		//u16Data++;
		//write_data_DAC(u16Data);


	/*	microblaze_disable_interrupts();

		char prochain_cara;
		int Valeur;

		prochain_cara='S';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara='E';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara='T';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara=' ';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara='1';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara='2';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara='3';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara='4';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);

		prochain_cara=';';
		calcul_de_etape_suivante(&enuEtapeDansLeDecodage, prochain_cara, &Valeur);


		microblaze_enable_interrupts();*/


	}

	/* never reached */
	cleanup_platform();

	return 0;
}


